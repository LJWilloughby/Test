#include <iostream>
#include <windows.h>
#include <TlHelp32.h>

DWORD find_by_process_name(const wchar_t* process_name)
{
    DWORD pid = 0;
    HANDLE hndl = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS | TH32CS_SNAPMODULE, 0);
    if (hndl)
    {
        PROCESSENTRY32  process = { sizeof(PROCESSENTRY32) };
        Process32First(hndl, &process);
        do
        {
            if (_wcsicmp(process.szExeFile, process_name) == 0)
            {
                pid = process.th32ProcessID;
                break;
            }
        } while (Process32Next(hndl, &process));

        CloseHandle(hndl);
    }

    return pid;
}

int main()
{
    ShellExecuteA(0, "open", "calc.exe", 0, 0, SW_SHOWNORMAL);
    if (find_by_process_name(L"calc.exe"))
        std::cout << "calculator is running\n";
    return 0;
}